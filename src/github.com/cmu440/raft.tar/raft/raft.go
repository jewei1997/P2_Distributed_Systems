//
// raft.go
// =======
// Write your code in this file
// We will use the original version of all other
// files for testing
//

package raft

import (
	"fmt"
	"github.com/cmu440/rpc"
	"math/rand"
	"sync"
	"time"
)

type Mode int

const (
	Follower  Mode = 0
	Candidate Mode = 1
	Leader    Mode = 2
)

//
// API
// ===
// This is an outline of the API that your raft implementation should
// expose.
//
// rf = Make(...)
//   Create a new Raft peer.
//
// rf.Start(command interface{}) (index, term, isleader)
//   Start agreement on a new log entry
//
// rf.GetState() (me, term, isLeader)
//   Ask a Raft peer for "me" (see line 58), its current term, and whether it thinks it
//   is a leader
//
// ApplyMsg
//   Each time a new entry is committed to the log, each Raft peer
//   should send an ApplyMsg to the service (e.g. tester) on the
//   same peer, via the applyCh channel passed to Make()
//

type LogEntry struct {
	Command      interface{} // command for state machine
	TermRecieved int         // term when entry was received by leader
}

//
// ApplyMsg
// ========
//
// As each Raft peer becomes aware that successive log entries are
// committed, the peer should send an ApplyMsg to the service (or
// tester) on the same peer, via the applyCh passed to Make()
//
type ApplyMsg struct {
	Index   int
	Command interface{}
}

//
// Raft struct
// ===========
//
// A Go object implementing a single Raft peer
//
type Raft struct {
	mux               sync.Mutex       // Lock to protect shared access to this peer's state
	peers             []*rpc.ClientEnd // RPC end points of all peers
	me                int              // this peer's index into peers[]
	applyCh           chan ApplyMsg    // applyCh is a channel on which the tester or service expects Raft to send ApplyMsg messages
	leaderHeartbeatCh chan *AppendEntriesArgs
	heartbeatCh       chan *AppendEntriesArgs
	heartbeatRespCh   chan int

	startLeaderModeCh chan int // startLeaderModeCh is a channel that starts the leader mode for this peer
	isLeader          bool     // bool indicating whether this Raft peer is a leader
	curMode           Mode     // indicates whether follower, candidate, or leader
	voteGrantedCh     chan bool

	// Your data here (2A, 2B).
	// Look at the Raft paper's Figure 2 for a description of what
	// state a Raft peer should maintain

	// Volatile state on all servers
	currentTerm int         // latest term server has seen
	votedFor    int         // candidateId that recieved vote in current term (or null if none)
	log         []*LogEntry // log entries
	commitIndex int         // index of highest log entry known to be commited
	lastApplied int         // index of highest log entry applied to state machine

	// Volatile State on leaders
	// Reinitialized after election
	nextIndex  []int // for each server, index of the next log entry to send to that server
	matchIndex []int // for each server, index of highest log entry known to be replicated on server
}

//
// GetState()
// ==========
//
// Return "me", current term and whether this peer
// believes it is the leader
//
func (rf *Raft) GetState() (int, int, bool) {
	// Let's print out the state of everyone
	/*
		for peer := 0; peer < len(GetPeers(rf)); peer++ {
			me, curTerm, isLeader := GetStateHelper(rf)
		}
	*/
	return GetStateHelper(rf)
}

func GetStateHelper(rf *Raft) (int, int, bool) {
	return GetMe(rf), GetCurTerm(rf), GetCurMode(rf) == Leader
}

//
// RequestVoteArgs
// ===============
//
// Example RequestVote RPC arguments structure
//
// Please note
// ===========
// Field names must start with capital letters!
//
type RequestVoteArgs struct {
	// Arguments
	Term         int // candidate's term
	CandidateId  int // candidate requesting vote
	LastLogIndex int // index of candidate's last log entry
	LastLogTerm  int // term of candidate's last log entry
}

//
// RequestVoteReply
// ================
//
// Example RequestVote RPC reply structure.
//
// Please note
// ===========
// Field names must start with capital letters!
//
//
type RequestVoteReply struct {
	// Results
	Term        int  // currentTerm for candidate to update itself
	VoteGranted bool // true means candidate received vote
}

type AppendEntriesArgs struct {
	Term         int         // leader's term
	LeaderId     int         // so follower can redirect clients
	PrevLogIndex int         // index of log entry immediately precending new ones
	PrevLogTerm  int         // term of PrevLogIndex
	Entries      []*LogEntry // log entries to store (empty for heartbeat; may send more than one for efficiency)
	LeaderCommit int         // leader's commitIndex
}

type AppendEntriesReply struct {
	Term    int  // currentTerm, for leader to update itself
	Success bool // true if follower contained entry matching prevLogIndex and prevLogTerm
}

//
// RequestVote
// ===========
//
// Example RequestVote RPC handler
//
func (rf *Raft) RequestVote(args *RequestVoteArgs, reply *RequestVoteReply) {
	reply.Term = GetCurTerm(rf)

	if args.Term < GetCurTerm(rf) {
		reply.VoteGranted = false
		return
	}

	if GetCurTerm(rf) == args.Term && GetCurMode(rf) == Leader {
		reply.VoteGranted = false
		return
	}

	// not voting for another candidate once we voted for someone
	if GetCurTerm(rf) == args.Term && GetVotedFor(rf) != -1 && GetVotedFor(rf) != args.CandidateId {
		reply.VoteGranted = false
		return
	}

	if GetCurTerm(rf) < args.Term { // we are outdated
		SetVotedFor(rf, -1)
		SetCurTerm(rf, args.Term)
	}

	// Stop trying to be leader by sending something to heartbeatCh
	rf.heartbeatCh <- &AppendEntriesArgs{Term: args.Term}
	<-rf.heartbeatRespCh

	SetVotedFor(rf, args.CandidateId)
	reply.VoteGranted = true
}

//
// sendRequestVote
// ===============
//
// Example code to send a RequestVote RPC to a peer
//
// peer int -- index of the target peer in
// rf.peers[]
//
// args *RequestVoteArgs -- RPC arguments in args
//
// reply *RequestVoteReply -- RPC reply
//
// The types of args and reply passed to Call() must be
// the same as the types of the arguments declared in the
// handler function (including whether they are pointers)
//
// The rpc package simulates a lossy network, in which peers
// may be unreachable, and in which requests and replies may be lost
//
// Call() sends a request and waits for a reply
//
// If a reply arrives within a timeout interval, Call() returns true;
// otherwise Call() returns false
//
// Thus Call() may not return for a while
//
// A false return can be caused by a dead peer, a live peer that
// can't be reached, a lost request, or a lost reply
//
// Call() is guaranteed to return (perhaps after a delay)
// *except* if the handler function on the peer side does not return
//
// Thus there
// is no need to implement your own timeouts around Call()
//
// Please look at the comments and documentation in ../rpc/rpc.go
// for more details
//
// If you are having trouble getting RPC to work, check that you have
// capitalized all field names in the struct passed over RPC, and
// that the caller passes the address of the reply struct with "&",
// not the struct itself
//
func (rf *Raft) sendRequestVote(peer int, args *RequestVoteArgs, reply *RequestVoteReply) bool {
	for true {
		ok := rf.peers[peer].Call("Raft.RequestVote", args, reply)
		if ok {
			rf.voteGrantedCh <- reply.VoteGranted
			return true
		}
	}
	return false
}

func (rf *Raft) AppendEntries(args *AppendEntriesArgs, reply *AppendEntriesReply) {
	rf.heartbeatCh <- args // reset leader election timeout timer
	<-rf.heartbeatRespCh
	if GetCurTerm(rf) < args.Term {
		SetCurTerm(rf, args.Term)
	}
	reply.Term = GetCurTerm(rf)
	reply.Success = true // TODO: add logic here to determine if actually success
}

func (rf *Raft) sendAppendEntries(peer int, args *AppendEntriesArgs, reply *AppendEntriesReply) bool {
	for true {
		if rf.peers[peer].Call("Raft.AppendEntries", args, reply) {
			return true
		}
	}
	return false
}

//
// Start
// =====
//
// The service using Raft (e.g. a k/v peer) wants to start
// agreement on the next command to be appended to Raft's log
//
// If this peer is not the leader, return false
//
// Otherwise start the agreement and return immediately
//
// There is no guarantee that this command will ever be committed to
// the Raft log, since the leader may fail or lose an election
//
// The first return value is the index that the command will appear at
// if it is ever committed
//
// The second return value is the current term
//
// The third return value is true if this peer believes it is
// the leader
//
func (rf *Raft) Start(command interface{}) (int, int, bool) {
	index := -1
	term := -1
	isLeader := true

	// Your code here (2B)

	return index, term, isLeader
}

//
// Kill
// ====
//
// The tester calls Kill() when a Raft instance will not
// be needed again
//
// You are not required to do anything
// in Kill(), but it might be convenient to (for example)
// turn off debug output from this instance
//
func (rf *Raft) Kill() {
	// Your code here, if desired
}

//
// Make
// ====
//
// The service or tester wants to create a Raft peer
//
// The port numbers of all the Raft peers (including this one)
// are in peers[]
//
// This peer's port is peers[me]
//
// All the peers' peers[] arrays have the same order
//
// applyCh
// =======
//
// applyCh is a channel on which the tester or service expects
// Raft to send ApplyMsg messages
//
// Make() must return quickly, so it should start Goroutines
// for any long-running work
//
func Make(peers []*rpc.ClientEnd, me int, applyCh chan ApplyMsg) *Raft {
	rf := &Raft{
		peers:           peers,
		me:              me,
		applyCh:         applyCh,
		heartbeatCh:     make(chan *AppendEntriesArgs),
		heartbeatRespCh: make(chan int),
		log:             []*LogEntry{&LogEntry{TermRecieved: -1}}, // log is indexed starting at 1
		curMode:         Follower,
		votedFor:        -1,
		voteGrantedCh:   make(chan bool),
	}
	go FollowerMode(rf)
	return rf
}

func FollowerMode(rf *Raft) {
	SetCurMode(rf, Follower)
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	timer := time.NewTimer(time.Duration(r.Intn(300)+200) * time.Millisecond) // election leader timeout [150, 301) ms
	for {
		select {
		case <-timer.C:
			// timeout - start a leader election
			// if attemping to start leader election is successful, exit
			// otherwise, try again when timeout occurs again
			go CandidateMode(rf)
			return // exit FollowerMode
		case <-rf.heartbeatCh:
			// heartbeat received - reset timer
			timer.Reset(time.Duration(r.Intn(300)+200) * time.Millisecond)
			rf.heartbeatRespCh <- 1
		}
	}
}

func CandidateMode(rf *Raft) {
	SetCurMode(rf, Candidate)
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	timer := time.NewTimer(time.Duration(r.Intn(300)+200) * time.Millisecond) // election leader timeout [150, 301) ms
	LeaderElection(rf)
	numVoters := 1
	for {
		select {
		case <-timer.C:
			// vote for yourself
			LeaderElection(rf)
			numVoters = 1
			timer.Reset(time.Duration(r.Intn(300)+200) * time.Millisecond)
		case isGranted := <-rf.voteGrantedCh:
			if isGranted {
				numVoters++
			}
			if 2*numVoters > len(GetPeers(rf)) {
				// leader election was successful, go into leader mode and quit
				fmt.Println("Me = ", GetMe(rf), "candidate -> leader")
				go LeaderMode(rf)
				return
			}
		case appendEntriesArgs := <-rf.heartbeatCh:
			if appendEntriesArgs.Term >= GetCurTerm(rf) {
				// step down and go back to follower mode
				go FollowerMode(rf)
				rf.heartbeatRespCh <- 1
				return
			}
		}
	}
}

func LeaderElection(rf *Raft) {
	SetVotedFor(rf, GetMe(rf))
	IncrCurTerm(rf) // incr current term

	requestVoteArgs := &RequestVoteArgs{
		Term:         GetCurTerm(rf),
		CandidateId:  GetMe(rf),
		LastLogIndex: -1, // len(GetLog(rf)) - 1,
		LastLogTerm:  -1, // rf.log[len(GetLog(rf))-1].TermRecieved,
	}

	for peer := 0; peer < len(GetPeers(rf)); peer++ {
		if peer == GetMe(rf) {
			continue // don't send RPC to yourself
		}

		requestVoteReply := &RequestVoteReply{}
		go rf.sendRequestVote(peer, requestVoteArgs, requestVoteReply)
	}
}

func LeaderMode(rf *Raft) {
	SetCurMode(rf, Leader)
	SetIsLeader(rf, true)
	heartbeatTimer := time.NewTimer(0) // send the first heartbeat immediatley, all other heartbeats every 100 ms
	for {
		select {
		// TODO: need to add logic that checks whether we there is a leader of
		// higher term and if there is, go back to being a follower
		case <-heartbeatTimer.C:

			appendEntriesArgs := &AppendEntriesArgs{
				Term:     GetCurTerm(rf),
				LeaderId: GetMe(rf),
				// PrevLogIndex:  <- do later when you need to do log replication
				// PrevLogTerm: <- do later when you need to do log replication
				Entries:      GetLog(rf),
				LeaderCommit: GetCommitIndex(rf),
			}

			// send regular heart beats to peers
			for peer := 0; peer < len(GetPeers(rf)); peer++ {
				if peer == GetMe(rf) {
					continue
				}
				appendEntriesReply := &AppendEntriesReply{}

				go rf.sendAppendEntries(peer, appendEntriesArgs, appendEntriesReply)

			}
			heartbeatTimer.Reset(time.Duration(rand.Intn(100)) * time.Millisecond)

		case appendEntriesArgs := <-rf.heartbeatCh:
			if appendEntriesArgs.Term > GetCurTerm(rf) {
				go FollowerMode(rf)
				rf.heartbeatRespCh <- 1
				return
			}
		}
	}
}

func GetPeers(rf *Raft) []*rpc.ClientEnd {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	return rf.peers
}

func GetVotedFor(rf *Raft) int {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	return rf.votedFor
}

func SetVotedFor(rf *Raft, votedFor int) {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	rf.votedFor = votedFor
}

func GetMe(rf *Raft) int {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	return rf.me
}

func IncrCurTerm(rf *Raft) {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	rf.currentTerm++
}

func GetCurTerm(rf *Raft) int {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	return rf.currentTerm
}

func SetCurTerm(rf *Raft, term int) {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	rf.currentTerm = term
}

func GetLog(rf *Raft) []*LogEntry {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	return rf.log
}

func GetCommitIndex(rf *Raft) int {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	return rf.commitIndex
}

func GetIsLeader(rf *Raft) bool {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	return rf.isLeader
}

func SetIsLeader(rf *Raft, isLeader bool) {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	rf.isLeader = isLeader
}

func GetCurMode(rf *Raft) Mode {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	return rf.curMode
}

func SetCurMode(rf *Raft, mode Mode) {
	rf.mux.Lock()
	defer rf.mux.Unlock()
	rf.curMode = mode
}
